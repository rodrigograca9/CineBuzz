export default function Footer() {
    return (
      <footer className="bg-gray-800 text-white p-6">
        <div className="flex justify-between">
          <div>
            <h3 className="font-bold">Subscreve a Newsletter!</h3>
            <div className="flex gap-2 mt-2">
              <input
                type="email"
                placeholder="Insere o e-mail"
                className="p-2 rounded bg-gray-700 text-white"
              />
              <button className="bg-gray-600 p-2 rounded">Enviar</button>
            </div>
          </div>
          <div>
            <h3 className="font-bold">Segue-nos!</h3>
            <div className="flex gap-3 mt-2">
              <span className="bg-gray-700 p-2 rounded">📸</span>
              <span className="bg-gray-700 p-2 rounded">𝕏</span>
              <span className="bg-gray-700 p-2 rounded">📘</span>
              <span className="bg-gray-700 p-2 rounded">🎵</span>
              <span className="bg-gray-700 p-2 rounded">▶</span>
            </div>
          </div>
        </div>
      </footer>
    );
  }