import { useState } from "react";
import { useNavigate } from "react-router-dom"; // Importa o useNavigate

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate(); // Hook para navegação

  return (
    <nav className="bg-gray-900 text-white p-4 flex justify-between items-center">
      {/* Ao clicar em "CineBuzz", redirecionamos para a página principal */}
      <div
        className="text-xl font-bold cursor-pointer hover:text-gray-400 transition"
        onClick={() => navigate("/")} // Redireciona para a home
      >
        CineBuzz
      </div>

      <div className="flex gap-6 items-center">
        {/* Links de navegação sem recarregar a página */}
        <button
          onClick={() => navigate("/movies")}
          className="hover:text-gray-400 transition"
        >
          Filmes
        </button>

        <button
          onClick={() => navigate("/watchlist")}
          className="hover:text-gray-400 transition"
        >
          Watchlist
        </button>

        {/* Menu do Utilizador */}
        <div className="relative">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="flex items-center gap-2 bg-gray-800 px-3 py-2 rounded-full hover:bg-gray-700 transition"
          >
            <span className="bg-gray-700 w-6 h-6 rounded-full"></span> Utilizador ▼
          </button>

          {menuOpen && (
            <div className="absolute right-0 bg-gray-700 p-2 mt-2 w-40 rounded shadow-lg">
              <button
                onClick={() => navigate("/")}
                className="block w-full text-left p-2 hover:bg-gray-600 transition"
              >
                Início
              </button>
              <button
                onClick={() => navigate("/profile")}
                className="block w-full text-left p-2 hover:bg-gray-600 transition"
              >
                Perfil
              </button>
              <button
                onClick={() => navigate("/lists")}
                className="block w-full text-left p-2 hover:bg-gray-600 transition"
              >
                Listas
              </button>
              <button
                onClick={() => navigate("/likes")}
                className="block w-full text-left p-2 hover:bg-gray-600 transition"
              >
                Likes
              </button>
              <button
                onClick={() => alert("Logout realizado!")} // Substituir por função real
                className="block w-full text-left p-2 hover:bg-red-600 transition"
              >
                Log out
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
